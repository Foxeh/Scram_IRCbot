from distutils.core import setup

setup(name = 'ScramC2Bot',
      version = '0.1.3',
      description = 'Irc Command and Control Bot',
      author = 'Tyler Mikesell, Joshua Shank',
      author_email = 'tyler.mikesell@altamiracorp.com, joshua.shank@altamiracorp.com',
      packages = ['ScramC2Bot'],
     )